package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ClientDemo {
    public static void main(String[] args) {
        // Create a SessionFactory
        Configuration config = new Configuration();
        config.configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = config.buildSessionFactory();

        // Insert Operation
        insertDepartment(sessionFactory, "CSE", "C101", "S");
        insertDepartment(sessionFactory, "BioTECH", "E110", "B");

        // Delete Operation
        deleteDepartmentById(sessionFactory, 1);

        sessionFactory.close();
    }

    public static void insertDepartment(SessionFactory sessionFactory, String name, String location, String hodName) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Department department = new Department();
        department.setName(name);
        department.setLocation(location);
        department.setHodName(hodName);

        session.save(department);
        transaction.commit();
        session.close();
        System.out.println("Department inserted successfully.");
    }

    public static void deleteDepartmentById(SessionFactory sessionFactory, int departmentId) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        String hql = "DELETE FROM Department WHERE departmentId = ?1";
        Query query = session.createQuery(hql);
        query.setParameter(1, departmentId);

        int rowsAffected = query.executeUpdate();
        transaction.commit();
        session.close();

        if (rowsAffected > 0) {
            System.out.println("Department with ID " + departmentId + " deleted successfully.");
        } else {
            System.out.println("No department found with ID " + departmentId);
        }
    }
}
